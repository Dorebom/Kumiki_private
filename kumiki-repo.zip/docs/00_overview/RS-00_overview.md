---
id: RS-00_overview
title: Kumiki 概要
canonical_parent: RS-00_overview
refines: []
derives_from: []
satisfies: []
depends_on: []
integrates_with: []
constrains: []
conflicts_with: []
supersedes: []
---

# Kumiki 概要

Kumiki は、既存リポジトリに“あと付け”で導入できる DocOps 基盤です。
FrontMatter 規約に基づく自動検証・トレース・インデクシングを提供します。
