---
id: TEST-overview
title: テスト戦略 概要
canonical_parent: RS-00_overview
refines: []
derives_from: []
satisfies: []
depends_on: []
integrates_with: []
constrains: []
conflicts_with: []
supersedes: []
---

# テスト戦略 概要
- CLI のユニットテスト（FMパーサ、検証、グラフ構築）
- ルール違反ケースの回帰テスト
- 大規模MD集合に対するパフォーマンス監視
