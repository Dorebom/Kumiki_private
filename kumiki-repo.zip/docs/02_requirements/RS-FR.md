---
id: RS-FR
title: 機能要件（FR）
canonical_parent: RS-00_overview
refines: []
derives_from: [RS-HLF]
satisfies: []
depends_on: []
integrates_with: []
constrains: []
conflicts_with: []
supersedes: []
---

# 機能要件（FR）
- FrontMatter 解析→有向グラフ構築
- TF-IDF 索引生成と簡易検索
- ルールチェック（単一 canonical_parent / 語彙制限）
- レポート出力（未達/孤立/循環など）
