---
id: RS-HLF
title: 高位機能要件（HLF）
canonical_parent: RS-00_overview
refines: []
derives_from: []
satisfies: []
depends_on: []
integrates_with: []
constrains: []
conflicts_with: []
supersedes: []
---

# 高位機能要件（HLF）
- 既存ドキュメントを移動せずに解析対象にできること（sources.yml）
- FrontMatter（フラット）に基づく一貫した検証を行うこと
- Graph/Index/Reports を自動生成できること
- CI で最小ゲートを提供できること
