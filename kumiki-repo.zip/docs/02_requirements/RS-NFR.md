---
id: RS-NFR
title: 非機能要件（NFR）
canonical_parent: RS-00_overview
refines: []
derives_from: [RS-HLF]
satisfies: []
depends_on: []
integrates_with: []
constrains: []
conflicts_with: []
supersedes: []
---

# 非機能要件（NFR）
- Obsidian 互換（.obsidian は解析対象外）
- CI の実行時間は短い（最小ゲート）
- エラーメッセージは対象ファイルと理由を明瞭に表示
