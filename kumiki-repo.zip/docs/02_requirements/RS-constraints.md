---
id: RS-constraints
title: 制約・準拠（CN）
canonical_parent: RS-00_overview
refines: []
derives_from: []
satisfies: []
depends_on: []
integrates_with: []
constrains: []
conflicts_with: []
supersedes: []
---

# 制約・準拠（CN）
- FrontMatter はフラット 1 段、配列は文字列 ID のみ
- `canonical_parent` は必ず 1 つ
- relations は固定語彙の範囲内で使用
